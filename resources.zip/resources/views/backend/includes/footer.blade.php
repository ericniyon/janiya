<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6 footer-copyright">
                <p class="mb-0">Copyright 2022 © Janiya All rights reserved.</p>
            </div>
            <div class="col-md-6">
                <p class="pull-right mb-0">Mult vendor E-Commerce</p>
            </div>
        </div>
    </div>
</footer>
