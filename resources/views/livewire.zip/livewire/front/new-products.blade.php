<div class="theme-card">
    <h5 class="title-border">new product</h5>
    <div class="offer-slider slide-1 slick-initialized slick-slider"><button class="slick-prev slick-arrow" aria-label="Previous" type="button" style="display: block;">Previous</button><div class="slick-list draggable"><div class="slick-track" style="opacity: 1; width: 1530px; transform: translate3d(-306px, 0px, 0px);"><div class="slick-slide slick-cloned" data-slick-index="-1" aria-hidden="true" tabindex="-1" style="width: 306px;"><div><div style="width: 100%; display: inline-block;">
            <div class="media">
                <a href="" tabindex="-1"><img class="img-fluid blur-up lazyloaded" src="../assets/images/fashion/pro/001.jpg" alt=""></a>
                <div class="media-body align-self-center">
                    <div class="rating"><i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i></div><a href="product-page(no-sidebar).html" tabindex="-1">
                        <h6>Slim Fit Cotton Shirt</h6>
                    </a>
                    <h4>$500.00</h4>
                </div>
            </div>
            <div class="media">
                <a href="" tabindex="-1"><img class="img-fluid blur-up lazyloaded" src="../assets/images/fashion/pro/4.jpg" alt=""></a>
                <div class="media-body align-self-center">
                    <div class="rating"><i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i></div><a href="product-page(no-sidebar).html" tabindex="-1">
                        <h6>Slim Fit Cotton Shirt</h6>
                    </a>
                    <h4>$500.00</h4>
                </div>
            </div>
            <div class="media">
                <a href="" tabindex="-1"><img class="img-fluid blur-up lazyloaded" src="../assets/images/fashion/pro/19.jpg" alt=""></a>
                <div class="media-body align-self-center">
                    <div class="rating"><i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i></div><a href="product-page(no-sidebar).html" tabindex="-1">
                        <h6>Slim Fit Cotton Shirt</h6>
                    </a>
                    <h4>$500.00</h4>
                </div>
            </div>
        </div></div></div><div class="slick-slide slick-current slick-active" data-slick-index="0" aria-hidden="false" style="width: 306px;"><div><div style="width: 100%; display: inline-block;">
            <div class="media">
                <a href="" tabindex="0"><img class="img-fluid blur-up lazyloaded" src="../assets/images/fashion/pro/1.jpg" alt=""></a>
                <div class="media-body align-self-center">
                    <div class="rating"><i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i></div><a href="product-page(no-sidebar).html" tabindex="0">
                        <h6>Slim Fit Cotton Shirt</h6>
                    </a>
                    <h4>$500.00</h4>
                </div>
            </div>
            <div class="media">
                <a href="" tabindex="0"><img class="img-fluid blur-up lazyloaded" src="../assets/images/fashion/pro/011.jpg" alt=""></a>
                <div class="media-body align-self-center">
                    <div class="rating"><i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i></div><a href="product-page(no-sidebar).html" tabindex="0">
                        <h6>Slim Fit Cotton Shirt</h6>
                    </a>
                    <h4>$500.00</h4>
                </div>
            </div>
            <div class="media">
                <a href="" tabindex="0"><img class="img-fluid blur-up lazyloaded" src="../assets/images/fashion/pro/16.jpg" alt=""></a>
                <div class="media-body align-self-center">
                    <div class="rating"><i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i></div><a href="product-page(no-sidebar).html" tabindex="0">
                        <h6>Slim Fit Cotton Shirt</h6>
                    </a>
                    <h4>$500.00</h4>
                </div>
            </div>
        </div></div></div><div class="slick-slide" data-slick-index="1" aria-hidden="true" tabindex="-1" style="width: 306px;"><div><div style="width: 100%; display: inline-block;">
            <div class="media">
                <a href="" tabindex="-1"><img class="img-fluid blur-up lazyloaded" src="../assets/images/fashion/pro/001.jpg" alt=""></a>
                <div class="media-body align-self-center">
                    <div class="rating"><i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i></div><a href="product-page(no-sidebar).html" tabindex="-1">
                        <h6>Slim Fit Cotton Shirt</h6>
                    </a>
                    <h4>$500.00</h4>
                </div>
            </div>
            <div class="media">
                <a href="" tabindex="-1"><img class="img-fluid blur-up lazyloaded" src="../assets/images/fashion/pro/4.jpg" alt=""></a>
                <div class="media-body align-self-center">
                    <div class="rating"><i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i></div><a href="product-page(no-sidebar).html" tabindex="-1">
                        <h6>Slim Fit Cotton Shirt</h6>
                    </a>
                    <h4>$500.00</h4>
                </div>
            </div>
            <div class="media">
                <a href="" tabindex="-1"><img class="img-fluid blur-up lazyloaded" src="../assets/images/fashion/pro/19.jpg" alt=""></a>
                <div class="media-body align-self-center">
                    <div class="rating"><i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i></div><a href="product-page(no-sidebar).html" tabindex="-1">
                        <h6>Slim Fit Cotton Shirt</h6>
                    </a>
                    <h4>$500.00</h4>
                </div>
            </div>
        </div></div></div><div class="slick-slide slick-cloned" data-slick-index="2" aria-hidden="true" tabindex="-1" style="width: 306px;"><div><div style="width: 100%; display: inline-block;">
            <div class="media">
                <a href="" tabindex="-1"><img class="img-fluid blur-up lazyloaded" src="../assets/images/fashion/pro/1.jpg" alt=""></a>
                <div class="media-body align-self-center">
                    <div class="rating"><i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i></div><a href="product-page(no-sidebar).html" tabindex="-1">
                        <h6>Slim Fit Cotton Shirt</h6>
                    </a>
                    <h4>$500.00</h4>
                </div>
            </div>
            <div class="media">
                <a href="" tabindex="-1"><img class="img-fluid blur-up lazyloaded" src="../assets/images/fashion/pro/011.jpg" alt=""></a>
                <div class="media-body align-self-center">
                    <div class="rating"><i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i></div><a href="product-page(no-sidebar).html" tabindex="-1">
                        <h6>Slim Fit Cotton Shirt</h6>
                    </a>
                    <h4>$500.00</h4>
                </div>
            </div>
            <div class="media">
                <a href="" tabindex="-1"><img class="img-fluid blur-up lazyloaded" src="../assets/images/fashion/pro/16.jpg" alt=""></a>
                <div class="media-body align-self-center">
                    <div class="rating"><i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i></div><a href="product-page(no-sidebar).html" tabindex="-1">
                        <h6>Slim Fit Cotton Shirt</h6>
                    </a>
                    <h4>$500.00</h4>
                </div>
            </div>
        </div></div></div><div class="slick-slide slick-cloned" data-slick-index="3" aria-hidden="true" tabindex="-1" style="width: 306px;"><div><div style="width: 100%; display: inline-block;">
            <div class="media">
                <a href="" tabindex="-1"><img class="img-fluid blur-up lazyloaded" src="../assets/images/fashion/pro/001.jpg" alt=""></a>
                <div class="media-body align-self-center">
                    <div class="rating"><i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i></div><a href="product-page(no-sidebar).html" tabindex="-1">
                        <h6>Slim Fit Cotton Shirt</h6>
                    </a>
                    <h4>$500.00</h4>
                </div>
            </div>
            <div class="media">
                <a href="" tabindex="-1"><img class="img-fluid blur-up lazyloaded" src="../assets/images/fashion/pro/4.jpg" alt=""></a>
                <div class="media-body align-self-center">
                    <div class="rating"><i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i></div><a href="product-page(no-sidebar).html" tabindex="-1">
                        <h6>Slim Fit Cotton Shirt</h6>
                    </a>
                    <h4>$500.00</h4>
                </div>
            </div>
            <div class="media">
                <a href="" tabindex="-1"><img class="img-fluid blur-up lazyloaded" src="../assets/images/fashion/pro/19.jpg" alt=""></a>
                <div class="media-body align-self-center">
                    <div class="rating"><i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i></div><a href="product-page(no-sidebar).html" tabindex="-1">
                        <h6>Slim Fit Cotton Shirt</h6>
                    </a>
                    <h4>$500.00</h4>
                </div>
            </div>
        </div></div></div></div></div><button class="slick-next slick-arrow" aria-label="Next" type="button" style="display: block;">Next</button></div>
</div>